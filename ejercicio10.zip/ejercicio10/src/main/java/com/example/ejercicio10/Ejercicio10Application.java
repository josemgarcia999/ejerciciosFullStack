package com.example.ejercicio10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio10Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio10Application.class, args);
	}

}
