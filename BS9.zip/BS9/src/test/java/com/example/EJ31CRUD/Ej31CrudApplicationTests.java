package com.example.EJ31CRUD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej31CrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
