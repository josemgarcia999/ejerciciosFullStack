package com.example.EJ31CRUD.Profesor.infraestructure.controller.dto.imput;


import lombok.Data;

@Data
public class ProfesorImputDTO {

    String idProfesor;
    String idPersona;
    String comments;
    String branch;

}
