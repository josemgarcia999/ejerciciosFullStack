package com.example.EJ31CRUD.Student.infraestructure.controller.dto.imput;


import lombok.Data;

@Data
public class StudentImputDTO {

    String idPersona;
    Integer numHoursWeek;
    String idProfesor;
    String branch;
    String comments;





}
