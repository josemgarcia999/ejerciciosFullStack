package com.example.EJ31CRUD.Profesor.infraestructure.repository;

import com.example.EJ31CRUD.Profesor.domain.ProfesorEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfesorRepo  extends JpaRepository<ProfesorEntity,String> {




}
