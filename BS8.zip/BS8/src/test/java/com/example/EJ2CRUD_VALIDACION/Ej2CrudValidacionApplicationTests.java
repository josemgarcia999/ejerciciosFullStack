package com.example.EJ2CRUD_VALIDACION;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ej2CrudValidacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
