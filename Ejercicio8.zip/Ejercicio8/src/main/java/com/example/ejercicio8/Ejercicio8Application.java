package com.example.ejercicio8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio8Application {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio8Application.class, args);
	}

}
